/**
 * Geocoding utility using Nominatim (OpenStreetMap) — free, no API key required.
 * Rate-limited to 1 request/second per Nominatim usage policy.
 */

interface GeocodeResult {
  latitude: number;
  longitude: number;
  display_name: string;
  quality: number; // 0-1 confidence
}

// Simple in-memory cache to avoid re-geocoding the same address
interface CacheEntry { result: GeocodeResult | null; ts: number }
const geocodeCache = new Map<string, CacheEntry>();
const CACHE_TTL = 7 * 24 * 60 * 60 * 1000; // 7 days
const MAX_CACHE_SIZE = 1000;

function getCached(key: string): GeocodeResult | null | undefined {
  const entry = geocodeCache.get(key);
  if (!entry) return undefined;
  if (Date.now() - entry.ts > CACHE_TTL) {
    geocodeCache.delete(key);
    return undefined;
  }
  return entry.result;
}

function setCache(key: string, result: GeocodeResult | null) {
  if (geocodeCache.size >= MAX_CACHE_SIZE) {
    // Evict oldest entries
    const keys = Array.from(geocodeCache.keys());
    for (let i = 0; i < Math.ceil(MAX_CACHE_SIZE * 0.2); i++) {
      geocodeCache.delete(keys[i]);
    }
  }
  geocodeCache.set(key, { result, ts: Date.now() });
}

/**
 * Geocode an address using Nominatim (OpenStreetMap) API.
 * Returns null if geocoding fails or address is invalid.
 * 
 * Rate limit: Nominatim requires max 1 request/second.
 * We add a small delay between calls when batch geocoding.
 */
export async function geocodeAddress(
  address: string,
  city: string,
  country: string = "Malaysia"
): Promise<GeocodeResult | null> {
  // Build the search query
  const query = [address, city, country].filter(Boolean).join(", ");
  
  // Check cache first
  const cacheKey = query.toLowerCase().trim();
  const cached = getCached(cacheKey);
  if (cached !== undefined) {
    return cached;
  }

  // Skip obviously invalid addresses
  if (!address || address.toLowerCase() === "n/a" || address.trim().length < 5) {
    setCache(cacheKey, null);
    return null;
  }

  try {
    const params = new URLSearchParams({
      q: query,
      format: "json",
      limit: "1",
      countrycodes: "my", // Malaysia country code
      addressdetails: "1",
    });

    const response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
      headers: {
        "User-Agent": "ERTH-Pickup-App/1.0",
        "Accept": "application/json",
      },
      signal: AbortSignal.timeout(8000), // 8 second timeout
    });

    if (!response.ok) {
      console.warn(`[geocode] API returned ${response.status} for: ${query}`);
      setCache(cacheKey, null);
      return null;
    }

    const results = await response.json();

    if (!Array.isArray(results) || results.length === 0) {
      // Try with just city if full address fails
      if (address !== city && city) {
        const cityParams = new URLSearchParams({
          q: `${city}, ${country}`,
          format: "json",
          limit: "1",
          countrycodes: "my",
        });

        const cityResponse = await fetch(`https://nominatim.openstreetmap.org/search?${cityParams}`, {
          headers: {
            "User-Agent": "ERTH-Pickup-App/1.0",
            "Accept": "application/json",
          },
          signal: AbortSignal.timeout(8000),
        });

        if (cityResponse.ok) {
          const cityResults = await cityResponse.json();
          if (Array.isArray(cityResults) && cityResults.length > 0) {
            const r = cityResults[0];
            const result: GeocodeResult = {
              latitude: parseFloat(r.lat),
              longitude: parseFloat(r.lon),
              display_name: r.display_name,
              quality: 0.4, // Lower quality - city-level only
            };
            setCache(cacheKey, result);
            return result;
          }
        }
      }

      console.warn(`[geocode] No results for: ${query}`);
      setCache(cacheKey, null);
      return null;
    }

    const r = results[0];
    const result: GeocodeResult = {
      latitude: parseFloat(r.lat),
      longitude: parseFloat(r.lon),
      display_name: r.display_name,
      quality: parseFloat(r.importance || "0.5"),
    };

    // Validate coordinates are within Malaysia bounds (roughly)
    if (result.latitude < 0.5 || result.latitude > 8 || result.longitude < 98 || result.longitude > 120) {
      console.warn(`[geocode] Coordinates outside Malaysia bounds: ${result.latitude}, ${result.longitude}`);
      setCache(cacheKey, null);
      return null;
    }

    setCache(cacheKey, result);
    return result;
  } catch (error) {
    console.warn(`[geocode] Error geocoding "${query}":`, error instanceof Error ? error.message : error);
    setCache(cacheKey, null);
    return null;
  }
}

/**
 * Batch geocode multiple addresses with rate limiting.
 * Nominatim requires max 1 request/second.
 * Returns a map of address keys to GeocodeResult.
 */
export async function batchGeocode(
  items: Array<{ address: string; city: string }>,
  onProgress?: (done: number, total: number) => void
): Promise<Map<string, GeocodeResult | null>> {
  const results = new Map<string, GeocodeResult | null>();
  const total = items.length;

  for (let i = 0; i < items.length; i++) {
    const { address, city } = items[i];
    const key = `${address}, ${city}`.toLowerCase().trim();

    // Skip if already cached
    if (results.has(key)) continue;

    const result = await geocodeAddress(address, city);
    results.set(key, result);

    onProgress?.(i + 1, total);

    // Rate limit: wait 1.1 seconds between requests (Nominatim policy)
    if (i < items.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 1100));
    }
  }

  return results;
}

/**
 * Quick geocode for a single address - used when creating orders.
 * Returns [latitude, longitude] or null.
 */
export async function quickGeocode(
  address: string,
  city: string
): Promise<[number, number] | null> {
  const result = await geocodeAddress(address, city);
  if (!result) return null;
  return [result.latitude, result.longitude];
}
