import { db } from "@/lib/db";
import { MAX_DAILY_POINTS, ZONES, detectZone } from "./zones";
import { format, addDays } from "date-fns";
import { isWeekend } from "date-fns";

// Haversine distance between two lat/lng points (returns km)
function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

interface ScheduleResult {
  scheduled: { orderId: string; date: string; points: number; zone: number }[];
  unscheduled: { orderId: string; reason: string }[];
}

export async function autoSchedule(userId: string): Promise<ScheduleResult> {
  const pendingOrders = await db.order.findMany({
    where: { status: "PENDING", userId, isErthbox: false }, // ERTHBOX orders are manually scheduled
    orderBy: { createdAt: "asc" },
  });

  if (pendingOrders.length === 0) {
    return { scheduled: [], unscheduled: [] };
  }

  // Fetch disabled zones from settings and re-detect zone for orders in disabled zones
  const disabledZonesSetting = await db.setting.findUnique({
    where: { userId_key: { userId, key: "disabledZones" } },
  });
  const disabledZones: number[] = disabledZonesSetting?.value
    ? JSON.parse(disabledZonesSetting.value)
    : [];

  // Re-detect zone for orders that are in a disabled zone
  const zoneUpdateOps: Promise<typeof pendingOrders[0]>[] = [];
  for (const order of pendingOrders) {
    if (disabledZones.includes(order.zone)) {
      const newZone = detectZone(order.city, disabledZones);
      if (newZone !== order.zone) {
        // Update the order's zone in DB so it gets grouped correctly
        zoneUpdateOps.push(
          db.order.update({ where: { id: order.id }, data: { zone: newZone } }).then(o => o)
        );
        (order as { zone: number }).zone = newZone; // Update in-memory for grouping below
      }
    }
  }
  await Promise.all(zoneUpdateOps);

  const holidays = await db.holiday.findMany({ where: { userId } });
  const holidayDates = new Set(holidays.map(h => h.date));

  const offDays = await db.offDay.findMany({ where: { userId } });
  const offDayDates = new Set(offDays.map(d => d.date));

  // Event days are treated like OFF days — no auto-scheduling on those days
  const eventOrders = await db.order.findMany({
    where: { isEvent: true, scheduledDate: { not: null }, userId },
    select: { scheduledDate: true },
  });
  const eventDates = new Set(eventOrders.map(e => e.scheduledDate).filter((d): d is string => d !== null));

  const today = new Date();
  const startDate = format(today, "yyyy-MM-dd");
  const lookAhead = 21; // Look ahead 21 calendar days
  const endDate = format(addDays(today, lookAhead), "yyyy-MM-dd");

  const existingOrders = await db.order.findMany({
    where: {
      status: { in: ["SCHEDULED", "CONFIRMED", "BOOKED"] },
      scheduledDate: { gte: startDate, lte: endDate },
      userId,
    },
  });

  const capacityMap: Record<string, { totalPoints: number; zones: Record<number, number> }> = {};
  for (const order of existingOrders) {
    if (!order.scheduledDate) continue;
    if (!capacityMap[order.scheduledDate]) {
      capacityMap[order.scheduledDate] = { totalPoints: 0, zones: {} };
    }
    capacityMap[order.scheduledDate].totalPoints += order.points;
    capacityMap[order.scheduledDate].zones[order.zone] =
      (capacityMap[order.scheduledDate].zones[order.zone] || 0) + 1;
  }

  // Build a map of existing order coordinates per day for proximity scoring
  const existingByDate: Record<string, { latitude: number | null; longitude: number | null }[]> = {};
  for (const order of existingOrders) {
    if (!order.scheduledDate) continue;
    if (!existingByDate[order.scheduledDate]) existingByDate[order.scheduledDate] = [];
    existingByDate[order.scheduledDate].push({ latitude: order.latitude, longitude: order.longitude });
  }

  // Working days exclude OFF DAYS and EVENT days (full-day events)
  const workingDays: string[] = [];
  for (let i = 0; i < lookAhead; i++) {
    const day = addDays(today, i);
    const dateStr = format(day, "yyyy-MM-dd");
    if (!offDayDates.has(dateStr) && !eventDates.has(dateStr)) {
      workingDays.push(dateStr);
    }
  }

  const ordersByZone: Record<number, typeof pendingOrders> = {};
  for (const order of pendingOrders) {
    if (!ordersByZone[order.zone]) ordersByZone[order.zone] = [];
    ordersByZone[order.zone].push(order);
  }

  const scheduled: { orderId: string; date: string; points: number; zone: number }[] = [];
  const unscheduled: { orderId: string; reason: string }[] = [];

  const zonesInOrder = Object.entries(ordersByZone)
    .filter(([_, orders]) => orders.length > 0)
    .sort(([_, a], [__, b]) => b.length - a.length)
    .map(([zone]) => parseInt(zone));

  for (const zone of zonesInOrder) {
    const zoneOrders = ordersByZone[zone];

    for (const order of zoneOrders) {
      let assigned = false;

      const preferredDates = workingDays
        .map(date => {
          const sameZoneCount = capacityMap[date]?.zones[zone] || 0;
          const remainingCapacity = MAX_DAILY_POINTS - (capacityMap[date]?.totalPoints || 0);

          // Calculate proximity score using lat/lng
          let nearbyCount = 0;
          if (order.latitude && order.longitude) {
            const dayOrders = existingByDate[date] || [];
            for (const existing of dayOrders) {
              if (existing.latitude && existing.longitude) {
                const dist = haversineDistance(order.latitude, order.longitude, existing.latitude, existing.longitude);
                if (dist <= 5) nearbyCount++; // Within 5km
              }
            }
          }

          // Weighted score: zone clustering + geographic proximity
          const score = 0.6 * sameZoneCount + 0.4 * nearbyCount;

          return { date, sameZoneCount, nearbyCount, remainingCapacity, score };
        })
        .filter(d => {
          // No office pickups on holidays
          if (order.isOffice && holidayDates.has(d.date)) return false;
          // No office pickups on weekends (Sat/Sun)
          if (order.isOffice && isWeekend(parseISO(d.date))) return false;
          return order.points <= d.remainingCapacity;
        })
        .sort((a, b) => {
          if (b.score !== a.score) return b.score - a.score; // Higher score first
          return a.date.localeCompare(b.date); // Earlier date as tiebreaker
        });

      if (preferredDates.length > 0) {
        const bestDate = preferredDates[0];
        scheduled.push({ orderId: order.id, date: bestDate.date, points: order.points, zone: order.zone });

        if (!capacityMap[bestDate.date]) {
          capacityMap[bestDate.date] = { totalPoints: 0, zones: {} };
        }
        capacityMap[bestDate.date].totalPoints += order.points;
        capacityMap[bestDate.date].zones[zone] = (capacityMap[bestDate.date].zones[zone] || 0) + 1;

        // Also update existingByDate for proximity scoring of subsequent orders
        if (!existingByDate[bestDate.date]) existingByDate[bestDate.date] = [];
        existingByDate[bestDate.date].push({ latitude: order.latitude, longitude: order.longitude });

        assigned = true;
      }

      if (!assigned) {
        unscheduled.push({ orderId: order.orderId, reason: "No available capacity in the next 21 days (blocked by OFF DAYS, weekends, holidays, or capacity)" });
      }
    }
  }

  await db.$transaction(
    scheduled.map(item => 
      db.order.update({ 
        where: { id: item.orderId }, 
        data: { status: "SCHEDULED", scheduledDate: item.date } 
      })
    )
  );

  return { scheduled, unscheduled };
}

// Helper to parse ISO date string - avoids importing from date-fns again
function parseISO(dateStr: string): Date {
  const [year, month, day] = dateStr.split("-").map(Number);
  return new Date(year, month - 1, day);
}
