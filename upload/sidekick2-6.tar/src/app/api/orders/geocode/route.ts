import { db } from "@/lib/db";
import { requireAuth } from "@/lib/session";
import { logAudit } from "@/lib/audit";
import { geocodeAddress } from "@/lib/geocode";
import { NextRequest, NextResponse } from "next/server";

// POST /api/orders/geocode - Batch geocode orders that have no lat/lng
// Admin/Support/Hero can access
export async function POST(request: NextRequest) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: "Your session has expired. Please sign in again." }, { status: 401 });

  try {
    const body = await request.json().catch(() => ({}));
    const userId = body.userId; // Optional: geocode only for a specific hero
    const limit = Math.min(body.limit || 50, 40); // Max 40 per batch to prevent timeout

    // Find orders without coordinates
    const where: Record<string, unknown> = {
      OR: [
        { latitude: null },
        { longitude: null },
      ],
      address: { not: "N/A" },
    };
    if (userId) where.userId = userId;
    // Hero users can only geocode their own orders; Admin/Support can geocode all
    if (user.role === "HERO") where.userId = user.id;

    const orders = await db.order.findMany({
      where,
      select: { id: true, orderId: true, address: true, city: true },
      take: limit,
      orderBy: { createdAt: "desc" },
    });

    if (orders.length === 0) {
      return NextResponse.json({ message: "No orders without coordinates found", geocoded: 0, failed: 0 });
    }

    let geocoded = 0;
    let failed = 0;
    const errors: string[] = [];

    for (let i = 0; i < orders.length; i++) {
      const order = orders[i];

      try {
        const result = await geocodeAddress(order.address, order.city);
        if (result) {
          await db.order.update({
            where: { id: order.id },
            data: { latitude: result.latitude, longitude: result.longitude },
          });
          geocoded++;
        } else {
          failed++;
        }
      } catch {
        failed++;
        errors.push(`#${order.orderId}: geocoding failed`);
      }

      // Rate limit: 1.1s between Nominatim requests (policy: max 1/sec)
      if (i < orders.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 1100));
      }
    }

    // Audit log
    await logAudit({
      userId: user.id,
      action: "GEOCODE",
      entity: "Order",
      details: JSON.stringify({ geocoded, failed, total: orders.length, by: user.role }),
    });

    return NextResponse.json({
      message: `Geocoded ${geocoded} of ${orders.length} orders`,
      geocoded,
      failed,
      total: orders.length,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    console.error("[orders/geocode] POST error:", error);
    return NextResponse.json({ error: "Failed to geocode orders" }, { status: 500 });
  }
}

// GET /api/orders/geocode - Check how many orders need geocoding
// Admin/Support/Hero can access
export async function GET(request: NextRequest) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: "Your session has expired. Please sign in again." }, { status: 401 });

  try {
    // Hero users see only their own stats; Admin/Support see global stats
    const isHero = user.role === "HERO";
    const baseWhere = isHero ? { userId: user.id } : {};
    
    const totalOrders = await db.order.count({ where: baseWhere });
    const ordersWithCoords = await db.order.count({
      where: { ...baseWhere, AND: [{ latitude: { not: null } }, { longitude: { not: null } }] },
    });
    const ordersWithoutCoords = await db.order.count({
      where: {
        ...baseWhere,
        OR: [{ latitude: null }, { longitude: null }],
        address: { not: "N/A" },
      },
    });

    return NextResponse.json({
      totalOrders,
      ordersWithCoords,
      ordersWithoutCoords,
    });
  } catch (error) {
    console.error("[orders/geocode] GET error:", error);
    return NextResponse.json({ error: "Failed to get geocode status" }, { status: 500 });
  }
}
