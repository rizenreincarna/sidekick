# Task 12: Fix Medium and Low Priority Bugs

**Agent:** Senior Developer  
**Date:** 2025-01-21

## Summary
Fixed 7 medium/low priority bugs across the application — 3 in frontend page.tsx, 1 in ai-assistant.tsx, 2 in API routes, and 1 backend optimization.

## Bugs Fixed

### 1. Admin/Support Dashboards Don't Refresh on onRefresh (MEDIUM)
**File:** `src/app/page.tsx`
- Root cause: AdminDashboard and SupportDashboard accepted `onRefresh` prop but never used it to re-fetch their own data
- Fix: Added `dashboardRefreshKey` state in parent `HomePage`, incremented in `refreshAll`, passed through `DashboardTab` as `refreshKey` prop
- AdminDashboard and SupportDashboard now include `refreshKey` in their fetch URL as `&_k=${refreshKey}` and as a useEffect dependency
- When any component calls `refreshAll()`, the key increments, triggering both dashboards to re-fetch

### 2. Native `<select>` in SupportDashboard (MEDIUM)
**File:** `src/app/page.tsx`
- Replaced native `<select>` element for order reassignment with shadcn `Select`, `SelectTrigger`, `SelectValue`, `SelectContent`, `SelectItem` components
- Uses `onValueChange` instead of `onChange` for the shadcn Select API
- Consistent styling with the rest of the application

### 3. ErthboxLocation Interface Missing `user` Field (MEDIUM)
**File:** `src/app/page.tsx`
- Added `user?: { id: string; username: string; displayName: string }` field to the `ErthboxLocation` interface
- Removed all `as ErthboxLocation & { user?: ... }` type assertions in ErthboxManagerSection (2 occurrences: active locations and inactive locations)
- Now uses `loc.user` directly with proper typing

### 4. AI Settings "Validate" Actually Saves (MEDIUM)
**File:** `src/components/ai-assistant.tsx`
- Renamed button text from "Validate" to "Save & Validate" since the `validateKey` function calls `PUT /api/ai/settings` which persists the key

### 5. Settings Tab Multiple API Calls Consolidation (LOW)
**File:** `src/app/page.tsx`
- Consolidated 6 separate `useEffect` hooks into 3 using `Promise.all`:
  1. Settings + 2FA status (related user settings)
  2. Off days (standalone)
  3. Zones + User Zones + AI zone suggestions (zone-related)
- Removed standalone `loadAiZoneSuggestions` function (now integrated into zone data effect)
- Reduces number of concurrent mount-time effects from 6 to 3

### 6. Import Encore Cross-User Duplicate Check Optimization (LOW)
**File:** `src/app/api/import/encore/route.ts`
- Replaced `db.order.findMany({ select: { orderId: true } })` (loads ALL orders in system) with targeted `IN` clause check
- Pre-parse CSV rows to collect all import order IDs first
- Use `db.order.findMany({ where: { orderId: { in: importOrderIds } }, select: { orderId: true, userId: true } })` to check only relevant IDs
- Uses `crossUserMap` (Map) instead of `allSystemOrderIds` (Set) for cross-user duplicate tracking

### 7. Support Stats Load Optimization (LOW)
**File:** `src/app/api/stats/support/route.ts`
- Added `_count` with filtered where clause for active orders count instead of counting from loaded objects
- Added `where` filter and `take: 200` limit to hero orders relation (only loads PENDING/SCHEDULED/CONFIRMED/BOOKED/COMPLETED)
- Removed unused fields (`notes`, `customerName`) from hero orders select
- Added `take: 50` limit to `allActiveOrders` query (prevents loading unlimited orders)
- Used `h._count.orders` for `activeOrders` and `totalOrders` calculations

## Verification
- ESLint passes with zero errors
- Dev server compiles successfully
- All changes are backward-compatible
