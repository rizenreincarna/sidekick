---
Task ID: 7
Agent: Backend Developer
Task: Fix 10 critical/high-priority API route bugs

Work Log:
1. **Bug 1 - Order Status Transition Validation** (CRITICAL)
   - File: `src/app/api/orders/[id]/route.ts`
   - Added VALID_TRANSITIONS map enforcing: PENDING→SCHEDULED, SCHEDULED→CONFIRMED|PENDING, CONFIRMED→BOOKED|SCHEDULED, BOOKED→COMPLETED|CONFIRMED, COMPLETED→(none)
   - Returns 400 with descriptive error for invalid transitions

2. **Bug 2 - SOS Answer Race Condition** (CRITICAL)
   - File: `src/app/api/sos/[id]/route.ts`
   - Wrapped entire SOS answer operation in `db.$transaction`
   - Used atomic `updateMany({ where: { id, status: "ACTIVE" }, data: { status: "ANSWERED", toUserId } })` pattern
   - If `count === 0`, throws error indicating SOS already answered
   - Support/Admin now MUST provide `assignToUserId` (no default to own ID)
   - Pre-check for ownership (hero can't answer own SOS) before transaction

3. **Bug 3 - Notification IDOR** (CRITICAL)
   - File: `src/app/api/notifications/route.ts`
   - Added IDOR protection: regular users can only create notifications for themselves (userId === user.id)
   - Only ADMIN/SUPPORT can create notifications for other users
   - Returns 403 for unauthorized cross-user notification creation

4. **Bug 4 - Duplicate Order IDs Rejected** (CRITICAL)
   - File: `src/app/api/orders/route.ts`
   - Changed duplicate check from creating with `_warning` to returning 409 error
   - Duplicate check now scopes to same user (orderId + userId)
   - Returns `{ error: "Duplicate order ID: order #XXX already exists for this user" }` with status 409

5. **Bug 5 - AI Action Payload Validation** (HIGH)
   - File: `src/app/api/ai/actions/[id]/route.ts`
   - Added validation for UPDATE_ORDER/RESCHEDULE_ORDER payload fields:
     - size: must be S, M, or L
     - scheduledDate: must match YYYY-MM-DD format and parse as valid date
     - customerName: max 100 chars
     - phone: max 20 chars
     - city: max 50 chars
     - points: must be integer 1-12
   - Returns 400 with descriptive error for each validation failure

6. **Bug 6 - ERTHBOX Delete Orphan Check** (HIGH)
   - File: `src/app/api/erthbox/[id]/route.ts`
   - Added `db.order.count({ where: { erthboxLocationId: id } })` check before deletion
   - Returns 400 with count of referencing orders if any exist
   - Prevents orphaned orders with dangling erthboxLocationId references

7. **Bug 7 - AI Chat Order Limit** (HIGH)
   - File: `src/app/api/ai/chat/route.ts`
   - Replaced single `findMany({ where: { userId } })` with 8 targeted queries:
     - pending: status PENDING, take 20
     - scheduledFuture: status SCHEDULED + future date, take 20
     - today: scheduledDate = today
     - thisWeek: scheduledDate in current week
     - upcomingEvents: isEvent + future date, take 10
     - activeErthbox: isErthbox + not COMPLETED, take 10
     - confirmed: status CONFIRMED, take 20
     - booked: status BOOKED, take 20
   - Added count queries for total, completed, events, erthbox
   - Deduped merged results for context display
   - Updated all context template references to use new variables

8. **Bug 8 - AI Prompt Injection Fix** (CRITICAL)
   - File: `src/app/api/ai/verify-address/route.ts`
   - Added input sanitization before including in AI prompt:
     - `safeAddress = (address || "N/A").replace(/[\n\r]/g, " ").slice(0, 200)`
     - `safeCity = (city || "N/A").replace(/[\n\r]/g, " ").slice(0, 100)`
   - Strips newlines (prevents prompt injection) and limits length

9. **Bug 9 - Batch Geocode Timeout Prevention** (CRITICAL)
   - File: `src/app/api/orders/geocode/route.ts`
   - Changed max batch limit from 200 to 40
   - 40 × 1.1s = 44s, within typical server timeouts

10. **Bug 10 - Sequential Holiday Seed → createMany** (HIGH)
    - Files: `src/app/api/users/route.ts`, `src/app/api/auth/register/route.ts`
    - Replaced `for` loop with individual `db.holiday.create()` calls
    - Now uses `db.holiday.createMany({ data: holidays.map(h => ({ ...h, userId })) })`
    - Single batch INSERT instead of 23 individual queries

Stage Summary:
- All 10 bugs fixed across 10 API route files
- All modified files pass ESLint with zero errors
- Dev server compiles successfully with no new errors
- Key security improvements: IDOR protection, race condition prevention, prompt injection mitigation
- Key performance improvements: targeted DB queries, batch inserts, batch size limits
