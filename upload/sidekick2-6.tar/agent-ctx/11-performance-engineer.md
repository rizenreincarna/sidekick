# Task 11 — Performance Engineer

## Summary
Optimized the application for concurrent user support (10+ users) with 7 changes across 8 files.

## Changes Made

### 1. SQLite WAL Mode (`src/lib/db.ts`)
- Added `PRAGMA journal_mode=WAL` after PrismaClient initialization
- Enables concurrent reads while writes are in progress

### 2. generateErthboxId() (`src/lib/erthbox.ts`)
- Replaced `findMany` (fetches ALL erthbox orders) with `findFirst({ orderBy: { orderId: "desc" } })`
- Reduces from O(n) scan of all orders to single-row query

### 3. Batch Scheduler Updates (`src/lib/scheduler.ts`)
- Replaced sequential `for...await db.order.update()` loop with `db.$transaction(scheduled.map(...))`
- Single atomic transaction instead of N individual queries

### 4. Geocode Cache TTL & Eviction (`src/lib/geocode.ts`)
- Added CacheEntry interface with timestamp
- 7-day TTL with automatic expiry
- Max 1000 entries with 20% LRU eviction
- All cache accesses now go through getCached/setCache helpers

### 5. TOTP Backup Code Security (`src/lib/totp.ts`)
- Replaced `Math.random().toString(36)` with `randomBytes(4).toString("hex")`
- Cryptographically secure random number generation

### 6. API Response Caching
- **Heroes** (`src/app/api/heroes/route.ts`): 5-second global cache
- **Stats** (`src/app/api/stats/route.ts`): 3-second per-user cache using Map

### 7. Orders Pagination (`src/app/api/orders/route.ts` + `src/app/page.tsx`)
- API now accepts `?page=1&limit=50`, returns `{ orders, total, page, totalPages }`
- Frontend adapted to extract `orders` array from paginated response
- All direct fetch("/api/orders?all=true") calls updated

## Verification
- ESLint: 0 errors
- Dev server: compiles and runs
- WAL mode confirmed in dev logs
