# Task 6: Fix 12 Frontend Bugs

## Agent: Frontend Developer

## Summary
Fixed all 12 critical/high/medium/low priority frontend bugs in `/home/z/my-project/src/app/page.tsx`.

## Changes Made

### Bug #1 (CRITICAL): ChatBubble Infinite Re-render Loop
- **Location**: ~line 5337-5357
- **Fix**: Replaced `lastSeenId` useState with `useRef<string | null>(null)` to break the `useEffect → setLastSeenId → re-render → useEffect` infinite cycle
- **Impact**: Eliminates infinite re-renders when chat polling detects new messages

### Bug #2 (CRITICAL): ChatDrawer Polling Infinite Loop
- **Location**: ~line 5406-5423
- **Fix**: Added `lastMsgIdRef` useRef synced via separate effect; removed `messages` from polling effect deps, using the ref instead
- **Impact**: Eliminates infinite re-renders caused by `messages` state change triggering polling effect recreation

### Bug #3 (HIGH): useFetchData Swallows Errors
- **Location**: ~line 631-641
- **Fix**: Added `error` and `isLoading` states to the hook; errors are now caught and exposed; empty URLs are skipped with early return
- **Impact**: Components using useFetchData can now display error states and loading indicators

### Bug #4 (HIGH): OrderCard Stale Date State
- **Location**: ~line 1044
- **Fix**: Added `if (open) setNewDate(order.scheduledDate || "")` to `onOpenChange` handler for date dialog
- **Impact**: Date dialog always shows current order date when opened, not stale value from previous edit

### Bug #5 (HIGH): deleteOrder Unchecked Response
- **Location**: ~line 805-813
- **Fix**: Now `await`s fetch response, checks `res.ok`, shows error toast with server error message on failure
- **Impact**: Users get feedback when deletion fails instead of false success message

### Bug #6 (HIGH): WhatsApp Template Auto-Save Fire-and-Forget
- **Location**: ~lines 3506, 3531, 3548, 3564
- **Fix**: All 4 template operations (add/update/delete/setDefault) now `await` fetch and check `res.ok`, showing error toast on failure
- **Impact**: Users are notified when template save operations fail

### Bug #7 (MEDIUM): OnboardingModal Step Reset
- **Location**: ~line 5778
- **Fix**: Added `useEffect(() => { if (open) { setTimeout(() => setStep(0), 0); } }, [open])` to reset step when modal opens
- **Impact**: Onboarding always starts from step 0 when reopened

### Bug #8 (CRITICAL perf): NotificationBell Double Fetch
- **Location**: ~line 5192-5214
- **Fix**: Replaced redundant `?limit=1` → `?limit=100` cascade with single `?limit=50` fetch
- **Impact**: Halves API calls for notification polling (every 30s)

### Bug #9 (MEDIUM): MiniBarChart Index Key
- **Location**: ~line 1372
- **Fix**: Changed `key={i}` to `key={d.date}` for stable React keys
- **Impact**: Proper React reconciliation for chart bars

### Bug #10 (MEDIUM): ScheduleTab Calendar Computations
- **Location**: ~line 2297-2302
- **Fix**: Wrapped calendar day computations in `useMemo` with `currentDate` dependency, renamed to `calendarDays`
- **Impact**: Prevents unnecessary recalculation of calendar days on every render

### Bug #11 (MEDIUM): AuditLog Search Debounce
- **Location**: ~line 2826
- **Fix**: Added `debouncedSearch` state with 400ms debounce via `setTimeout`; used in API fetch dependency instead of raw `search`
- **Impact**: Reduces API calls during rapid typing in audit log search

### Bug #12 (LOW): Erthbox Search Not Cleared
- **Location**: ~line 2042
- **Fix**: Added `if (!v) setErthboxSearch("")` to ERTHBOX toggle's `onCheckedChange` handler
- **Impact**: Search state is properly cleared when ERTHBOX mode is toggled off

## Verification
- `bun run lint` passes with zero errors
- Dev server compiles successfully
