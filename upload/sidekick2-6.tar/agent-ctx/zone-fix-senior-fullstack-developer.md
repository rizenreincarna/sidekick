# Task ID: zone-fix
# Agent: Senior Full-Stack Developer

## Summary
Fixed two major issues in the HERO Sidekick application:

### Issue 1: ZoneBadge Shows Wrong Zone Names
- **Root cause**: ZoneBadge always used hardcoded `ZONES` object, ignoring user zone overrides and custom zones
- **Fix**: Added `userZones` prop to ZoneBadge, OrderCard, OrdersTab, and SosTab; HomePage fetches `/api/user-zones` and passes data down the component tree
- **Files modified**: `src/app/page.tsx`

### Issue 2: Auto-Scheduler Doesn't Optimize for Fuel Efficiency
- **Root cause**: Scheduler only grouped by zone number, ignoring actual geographic distances between orders
- **Fix**: Added Haversine distance calculation and proximity scoring with weighted formula `0.6 * sameZoneCount + 0.4 * nearbyCount`
- **Files modified**: `src/lib/scheduler.ts`

## Verification
- ESLint: zero errors
- Dev server: compiles and runs successfully
- `/api/user-zones` endpoint confirmed being called in dev logs
